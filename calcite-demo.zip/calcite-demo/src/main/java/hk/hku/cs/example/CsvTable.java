package hk.hku.cs.example;

import org.apache.calcite.DataContext;
import org.apache.calcite.adapter.file.CsvEnumerator;
import org.apache.calcite.linq4j.AbstractEnumerable;
import org.apache.calcite.linq4j.Enumerable;
import org.apache.calcite.linq4j.Enumerator;
import org.apache.calcite.rel.type.RelDataType;
import org.apache.calcite.rel.type.RelDataTypeFactory;
import org.apache.calcite.schema.ScannableTable;
import org.apache.calcite.schema.impl.AbstractTable;
import org.apache.calcite.util.ImmutableIntList;
import org.apache.calcite.util.Source;
import org.apache.calcite.util.Sources;

import java.io.File;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class CsvTable extends AbstractTable implements ScannableTable {
    private final String tableName;
    private final String filePath;
    private final List<String> fieldNames;
    private final List<RelDataType> fieldTypes;
    private final RelDataType dataType;

    public CsvTable(String tableName, String filePath, List<String> fieldNames, List<RelDataType> fieldTypes, RelDataType dataType) {
        this.tableName = tableName;
        this.filePath = filePath;
        this.fieldNames = fieldNames;
        this.fieldTypes = fieldTypes;
        this.dataType = dataType;
    }

    @Override
    public RelDataType getRowType(RelDataTypeFactory typeFactory) {
        return typeFactory.copyType(dataType);
    }

    @Override
    public Enumerable<Object[]> scan(DataContext root) {
        File file = new File(filePath);
        Source source = Sources.of(file);
        AtomicBoolean cancelFlag = DataContext.Variable.CANCEL_FLAG.get(root);
        List<Integer> fields = ImmutableIntList.identity(fieldTypes.size());
        return new AbstractEnumerable<Object[]>() {
            @Override
            public Enumerator<Object[]> enumerator() {
                return new CsvEnumerator<>(
                        source,
                        cancelFlag,
                        false,
                        null,
                        CsvEnumerator.arrayConverter(fieldTypes, fields, false));
            }
        };
    }
}
