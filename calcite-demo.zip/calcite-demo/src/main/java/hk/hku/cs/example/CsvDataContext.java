package hk.hku.cs.example;

import org.apache.calcite.DataContext;
import org.apache.calcite.adapter.java.JavaTypeFactory;
import org.apache.calcite.jdbc.JavaTypeFactoryImpl;
import org.apache.calcite.linq4j.QueryProvider;
import org.apache.calcite.schema.SchemaPlus;
import org.checkerframework.checker.nullness.qual.Nullable;

import java.util.concurrent.atomic.AtomicBoolean;

public class CsvDataContext implements DataContext {
    private final SchemaPlus schemaPlus;

    public CsvDataContext(SchemaPlus schemaPlus) {
        this.schemaPlus = schemaPlus;
    }

    @Override
    public @Nullable SchemaPlus getRootSchema() {
        return schemaPlus;
    }

    @Override
    public JavaTypeFactory getTypeFactory() {
        return new JavaTypeFactoryImpl();
    }

    @Override
    public QueryProvider getQueryProvider() {
        throw new RuntimeException("un");
    }

    @Override
    public @Nullable Object get(String name) {
        if (Variable.CANCEL_FLAG.camelName.equals(name)) {
            return new AtomicBoolean(false);
        }
        return null;
    }
}
