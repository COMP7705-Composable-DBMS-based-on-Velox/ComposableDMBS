package hk.hku.cs.example;

import org.apache.calcite.adapter.enumerable.EnumerableConvention;
import org.apache.calcite.adapter.enumerable.EnumerableInterpretable;
import org.apache.calcite.adapter.enumerable.EnumerableRel;
import org.apache.calcite.adapter.enumerable.EnumerableRules;
import org.apache.calcite.config.CalciteConnectionConfig;
import org.apache.calcite.config.CalciteConnectionConfigImpl;
import org.apache.calcite.config.CalciteConnectionProperty;
import org.apache.calcite.jdbc.CalciteSchema;
import org.apache.calcite.jdbc.JavaTypeFactoryImpl;
import org.apache.calcite.plan.*;
import org.apache.calcite.plan.volcano.VolcanoPlanner;
import org.apache.calcite.prepare.CalciteCatalogReader;
import org.apache.calcite.rel.RelNode;
import org.apache.calcite.rel.rules.CoreRules;
import org.apache.calcite.rel.type.RelDataType;
import org.apache.calcite.rel.type.RelDataTypeFactory;
import org.apache.calcite.rex.RexBuilder;
import org.apache.calcite.runtime.Bindable;
import org.apache.calcite.sql.SqlExplainFormat;
import org.apache.calcite.sql.SqlExplainLevel;
import org.apache.calcite.sql.SqlNode;
import org.apache.calcite.sql.fun.SqlStdOperatorTable;
import org.apache.calcite.sql.parser.SqlParser;
import org.apache.calcite.sql.validate.SqlValidator;
import org.apache.calcite.sql.validate.SqlValidatorUtil;
import org.apache.calcite.sql2rel.SqlToRelConverter;
import org.apache.calcite.sql2rel.StandardConvertletTable;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class QueryProcessor {
    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            System.out.println("Usage: processor SQL_FILE");
            System.exit(-1);
        }

        String sqlQuery = Files.readString(Paths.get(args[0]));

        // Create the root schema and type factory
        CalciteSchema rootSchema = CalciteSchema.createRootSchema(false);
        RelDataTypeFactory typeFactory = new JavaTypeFactoryImpl();

        for (TpchTable tpchTable : TpchTable.values()) {
            // Add the TPC-H table to the root schema
            RelDataTypeFactory.Builder builder = typeFactory.builder();
            List<String> fieldNames = new ArrayList<>();
            List<RelDataType> fieldTypes = new ArrayList<>();
            for (TpchTable.Column column : tpchTable.columns) {
                RelDataType type = typeFactory.createJavaType(column.type);
                fieldNames.add(column.name);
                fieldTypes.add(type);
                builder.add(column.name, type.getSqlTypeName()).nullable(true);
            }
            String fileName = "data/" + tpchTable.name().toLowerCase() + ".csv";
            String filePath = Objects.requireNonNull(QueryProcessor.class.getClassLoader().getResource(fileName)).getFile();
            rootSchema.add(tpchTable.name(), new CsvTable(tpchTable.name(), filePath, fieldNames, fieldTypes, builder.build()));
        }

        // Create an SQL parser
        SqlParser sqlParser = SqlParser.create(sqlQuery);

        // Parse the query into an AST
        SqlNode parseAst = sqlParser.parseQuery();

        // Print and check the AST
        System.out.println("[Parsed query]");
        System.out.println(parseAst.toString());
        System.out.println();


        // Configure and instantiate the catalog reader
        Properties properties = new Properties();
        properties.setProperty(CalciteConnectionProperty.CASE_SENSITIVE.camelName(), "false");
        CalciteConnectionConfig connectionConfig = new CalciteConnectionConfigImpl(properties);
        CalciteCatalogReader catalogReader = new CalciteCatalogReader(
                rootSchema, Collections.emptyList(), typeFactory, connectionConfig
        );

        // Create the SQL validator using the standard operator table and default configuration
        SqlValidator sqlValidator = SqlValidatorUtil.newValidator(
                SqlStdOperatorTable.instance(), catalogReader, typeFactory, SqlValidator.Config.DEFAULT
        );

        // Validate thr initial AST
        SqlNode validAst = sqlValidator.validate(parseAst);
        System.out.println("[Validated query]");
        System.out.println(validAst.toString());
        System.out.println();

        // Create the optimization cluster to maintain planning information
        RelOptPlanner volcanoPlanner = new VolcanoPlanner();
        volcanoPlanner.addRelTraitDef(ConventionTraitDef.INSTANCE);
        RelOptCluster cluster = RelOptCluster.create(volcanoPlanner, new RexBuilder(typeFactory));

        RelOptTable.ViewExpander NOOP_EXPANDER = (rowType, queryString, schemaPath, viewPath) -> null;
        SqlToRelConverter relConverter = new SqlToRelConverter(
                NOOP_EXPANDER,
                sqlValidator,
                catalogReader,
                cluster,
                StandardConvertletTable.INSTANCE,
                SqlToRelConverter.config()
        );

        // Configure and instantiate the converter of the AST to logical plan
        RelNode logicalPlan = relConverter.convertQuery(validAst, false, true).rel;
        System.out.println(
                RelOptUtil.dumpPlan(
                        "[Logical plan]",
                        logicalPlan,
                        SqlExplainFormat.TEXT, // Change here to generate different format output strings.
                        SqlExplainLevel.EXPPLAN_ATTRIBUTES
                )
        );

        // Initialize optimizer/planner with the necessary rules
        RelOptPlanner planner = cluster.getPlanner();
//        planner.addRule(CoreRules.FILTER_TO_CALC);
//        planner.addRule(CoreRules.PROJECT_TO_CALC);
        planner.addRule(CoreRules.FILTER_INTO_JOIN);
        planner.addRule(EnumerableRules.ENUMERABLE_SORT_RULE);
        planner.addRule(EnumerableRules.ENUMERABLE_PROJECT_RULE);
        planner.addRule(EnumerableRules.ENUMERABLE_FILTER_RULE);
//        planner.addRule(EnumerableRules.ENUMERABLE_CALC_RULE);
        planner.addRule(EnumerableRules.ENUMERABLE_JOIN_RULE);
        planner.addRule(EnumerableRules.ENUMERABLE_AGGREGATE_RULE);
        planner.addRule(EnumerableRules.ENUMERABLE_TABLE_SCAN_RULE);

        // Define the type of the output plan
        logicalPlan = planner.changeTraits(logicalPlan, logicalPlan.getTraitSet().replace(EnumerableConvention.INSTANCE));
        planner.setRoot(logicalPlan);

        // Start the optimization process to obtain the most efficient physical plan based on the previous rule set
        EnumerableRel physicalPlan = (EnumerableRel) planner.findBestExp();

        // Display the physical plan
        System.out.println(
                RelOptUtil.dumpPlan(
                        "[Physical plan]",
                        physicalPlan,
                        SqlExplainFormat.JSON,  // Change here to generate different format output strings.
                        SqlExplainLevel.EXPPLAN_ATTRIBUTES
                )
        );

        // Compile generated code and obtain the executable program
        Bindable<Object[]> executablePlan = EnumerableInterpretable.toBindable(
                new HashMap<>(),
                null,
                physicalPlan,
                EnumerableRel.Prefer.ARRAY
        );

        // Run the program using a context simply providing access to the schema and print results
        long start = System.currentTimeMillis();
        for (Object[] row : executablePlan.bind(new CsvDataContext(rootSchema.plus()))) {
            System.out.println(Arrays.toString(row));
        }
        long finish = System.currentTimeMillis();
        System.out.println("Elapsed time " + (finish - start) + "ms");
    }
}


