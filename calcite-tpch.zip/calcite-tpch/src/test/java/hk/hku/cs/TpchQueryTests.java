package hk.hku.cs;

import org.junit.jupiter.api.Test;

public class TpchQueryTests {
    @Test
    public void testQ1() {

    }
}
