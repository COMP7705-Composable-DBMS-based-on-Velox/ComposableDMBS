package hk.hku.cs;

import org.apache.calcite.adapter.enumerable.EnumerableConvention;
import org.apache.calcite.jdbc.CalciteSchema;
import org.apache.calcite.jdbc.JavaTypeFactoryImpl;
import org.apache.calcite.plan.RelOptUtil;
import org.apache.calcite.rel.RelNode;
import org.apache.calcite.rel.type.RelDataType;
import org.apache.calcite.rel.type.RelDataTypeFactory;
import org.apache.calcite.sql.SqlExplainFormat;
import org.apache.calcite.sql.SqlExplainLevel;
import org.apache.calcite.sql.SqlNode;
import org.apache.calcite.sql.parser.SqlParseException;
import org.apache.calcite.tools.RuleSet;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Tpch {
    public static void main(String[] args) {

        CalciteSchema rootSchema = CalciteSchema.createRootSchema(false);
        RelDataTypeFactory typeFactory = new JavaTypeFactoryImpl();

        TpchUtil.addTables(rootSchema, typeFactory);

        TpchOptimizer tpchOptimizer = TpchOptimizer.create(rootSchema, typeFactory);

        try {
            String sqlFilename = "queries/" + args[0] + ".sql";
            String sqlFilePath = Objects.requireNonNull(Tpch.class.getClassLoader().getResource(sqlFilename)).getFile();
            String sql = Files.readString(Paths.get(sqlFilePath));

            SqlNode sqlTree = tpchOptimizer.parse(sql);
            SqlNode validatedSqlTree = tpchOptimizer.validate(sqlTree);
            RelNode relTree = tpchOptimizer.convert(validatedSqlTree, "text");
            RuleSet rules = TpchUtil.getRules();
            RelNode optimizeRelTree = tpchOptimizer.optimize(relTree, relTree.getTraitSet().plus(EnumerableConvention.INSTANCE),
                    rules, "text");

            String outputFilename = Objects.requireNonNull(Tpch.class.getClassLoader().getResource("")).getFile() + "output/" + args[0] + ".json";
            String physicalPlan = RelOptUtil.dumpPlan(
                    "[Physical plan]",
                    optimizeRelTree,
                    SqlExplainFormat.JSON,
                    SqlExplainLevel.EXPPLAN_ATTRIBUTES
            );
            TpchUtil.stringToFile(outputFilename, physicalPlan);

        } catch (SqlParseException | IOException e) {
            e.printStackTrace();
        }
    }
}
